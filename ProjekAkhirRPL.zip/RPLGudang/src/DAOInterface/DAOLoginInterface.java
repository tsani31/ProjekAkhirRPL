package DAOInterface;

public interface DAOLoginInterface {
    public String login(String username, String password);
}
